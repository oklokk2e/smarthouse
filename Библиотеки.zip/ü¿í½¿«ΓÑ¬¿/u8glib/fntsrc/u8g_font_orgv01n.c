/*
  Fontname: -FreeType-Org_v01-Medium-R-Normal--8-80-72-72-P-43-ISO10646-1
  Copyright: � www.orgdot.com
  Capital A Height: 0, '1' Height: 5
  Calculated Max Values w= 5 h= 5 x= 0 y= 2 dx= 6 dy= 0 ascent= 5 len= 5
  Font Bounding box     w=11 h=11 x= 0 y=-2
  Calculated Min Values           x= 0 y=-1 dx= 0 dy= 0
  Pure Font   ascent = 5 descent= 0
  X Font      ascent = 5 descent= 0
  Max Font    ascent = 5 descent=-1
*/
#include "u8g.h"
const u8g_fntpgm_uint8_t u8g_font_orgv01n[137] U8G_FONT_SECTION("u8g_font_orgv01n") = {
  1,11,11,0,254,5,0,0,0,0,42,58,0,5,255,5,
  0,3,51,67,160,64,160,3,51,67,64,224,64,1,18,34,
  128,128,4,65,81,240,2,17,33,128,2,85,101,8,16,32,
  64,128,2,85,101,248,136,136,136,248,2,21,37,128,128,128,
  128,128,2,85,101,248,8,248,128,248,2,85,101,248,8,248,
  8,248,2,85,101,136,136,248,8,8,2,85,101,248,128,248,
  8,248,2,85,101,248,128,248,136,248,2,85,101,248,8,8,
  8,8,2,85,101,248,136,248,136,248,2,85,101,248,136,248,
  8,248,2,20,36,128,0,0,128};
